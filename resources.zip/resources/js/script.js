$(document).ready(function(){
   /*  $('h1').css('background-color', 'red'); */ 
   /* sticky navigation */
   $('.js--section-features').waypoint(function(direction){
       //alert(direction);
        if(direction === "down"){
            $('nav').addClass('sticky');
        }  
        else{
            $('nav').removeClass('sticky');
        }   
    },
        {
       offset: '60px'
   });
    
    /* functions of hungry and show me more buttons */
    
   
});